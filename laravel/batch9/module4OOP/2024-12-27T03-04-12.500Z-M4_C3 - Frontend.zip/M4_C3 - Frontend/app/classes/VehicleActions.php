<?php


interface VehicleActions {
   
}
