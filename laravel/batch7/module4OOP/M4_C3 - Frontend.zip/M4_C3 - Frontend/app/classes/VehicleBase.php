<?php

abstract class VehicleBase {
    
}
