<?php


trait FileHandler {
    private $filePath = "";

    public function readFile() {
        
    }

    public function writeFile($data) {
        
    }
}
