<?php

namespace Database\Seeders;

use App\Models\SubCategory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SubCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        SubCategory::insert([
            
            ['category_id'=>1,'name'=>'Mobile'],
            ['category_id'=>1,'name'=>'Laptop'],
            ['category_id'=>2,'name'=>'Chair'],
            ['category_id'=>2,'name'=>'Table'],
            ['category_id'=>3,'name'=>'Shirt'],
                
            ]);
    }
}
