<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       for($i=1;$i<=10;$i++){
        Product::create([
            'name'=>'Product '.$i,
            'category_id'=>rand(1,3),
            'subcategory_id'=>rand(1,3),
            'type'=>rand(0,1)?'new':'used',
            'features'=>['wifi','bluetooth'],
            'image'=>'https://via.placeholder.com/150'
        ]);
    }

    }
}
