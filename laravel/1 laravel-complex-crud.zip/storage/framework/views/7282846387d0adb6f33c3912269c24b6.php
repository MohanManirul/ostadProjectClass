
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Product List</h2>
    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">Add New Product</a>
    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th><th>Name</th><th>Category</th><th>Subcategory</th><th>Type</th><th>Features</th><th>Image</th><th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+1); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e($product->category->name); ?></td>
                <td><?php echo e($product->subcategory->name); ?></td>
                <td><?php echo e(ucfirst($product->type)); ?></td>
                <td>
                    <?php
                        $features = is_array($product->features) ? $product->features : json_decode($product->features, true) ?? [];
                    ?>
                    <?php echo e(!empty($features) ? implode(', ', $features) : 'N/A'); ?>

                </td>
                <td><?php if($product->image): ?><img src="<?php echo e(asset('uploads/'.$product->image)); ?>" width="60" class="img-thumbnail"><?php endif; ?></td>
                <td>
                    <a href="<?php echo e(route('products.edit',$product->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($products->isEmpty()): ?><tr><td colspan="8" class="text-center">No products found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/products/index.blade.php ENDPATH**/ ?>