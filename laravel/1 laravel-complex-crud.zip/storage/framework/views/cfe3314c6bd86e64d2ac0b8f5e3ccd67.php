<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tenant Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background: #f4f6f9; }
        .card { border-radius: 15px; }
        .badge-approved { background: #28a745; }
        .badge-pending { background: #ffc107; color:#000; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark bg-primary px-4">
    <a class="btn btn-warning" href="/">Visit Website</a>
    <span class="navbar-brand">🏢 Tenant Dashboard</span>
    <a class="btn btn-light btn-sm" onclick="logout()">Logout</a>
</nav>

<div class="container mt-4">

    <!-- Summary -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card p-3">
                <h6>Total Bookings</h6>
                <h3>0</h3>
            </div>
        </div>
    </div>

    <!-- Booking List -->
    <div class="card">
        <div class="card-header fw-bold">
            📋 My Booked Apartments
        </div>

        <div class="card-body">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Apartment Name</th>
                        <th>Rent</th>
                        <th>Booked For</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="4" class="text-center text-muted">
                            No bookings available
                        </td>
                    </tr>

                    <!-- Example static row (optional) -->
                    <!--
                    <tr>
                        <td>1</td>
                        <td>Sunshine Apartment</td>
                        <td>৳ 15000</td>
                        <td>01 January 2026 to 31 December 2026</td>
                    </tr>
                    -->
                </tbody>
            </table>
        </div>
    </div>

</div>

 <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

 <script>

     const token = localStorage.getItem('tenant_token');
    console.log(token);
    
        if (!token) {
            window.location.href = "/tenant/login";
            return;
        }

function logout() {
        axios.post('/api/v1/logout', {}, {
            headers: {
                Authorization: 'Bearer ' + token
            }
        }).then(() => {
            localStorage.removeItem('tenant_token');
            window.location.href = "/tenant/login";
        });
    }

 </script>
</body>
</html>
<?php /**PATH C:\laragon\www\sanctum-api-class\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>