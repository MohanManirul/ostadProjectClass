

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Edit Product</h2>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary mb-3">Back</a>

    <!-- Validation Errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Product Name -->
        <div class="mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $product->name)); ?>">
        </div>

        <!-- Category -->
        <div class="mb-3">
            <label class="form-label">Category</label>
            <select name="category_id" id="category" class="form-select">
                <option value="">Select Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php echo e($product->category_id == $cat->id ? 'selected' : ''); ?>>
                        <?php echo e($cat->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Subcategory -->
        <div class="mb-3">
            <label class="form-label">Subcategory</label>
            <select name="subcategory_id" id="subcategory" class="form-select">
                <option value="<?php echo e($product->subcategory_id); ?>"><?php echo e($product->subcategory->name); ?></option>
            </select>
        </div>

        <!-- Type (Radio) -->
        <div class="mb-3">
            <label class="form-label d-block">Type</label>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" value="new" <?php echo e($product->type == 'new' ? 'checked' : ''); ?>>
                <label class="form-check-label">New</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" value="used" <?php echo e($product->type == 'used' ? 'checked' : ''); ?>>
                <label class="form-check-label">Used</label>
            </div>
        </div>

        <!-- Features (Checkbox) -->
        <div class="mb-3">
            <label class="form-label d-block">Features</label>
            <?php $features = $product->features ?? []; ?>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="features[]" value="wifi" <?php echo e(in_array('wifi', $features) ? 'checked' : ''); ?>>
                <label class="form-check-label">Wifi</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="features[]" value="bluetooth" <?php echo e(in_array('bluetooth', $features) ? 'checked' : ''); ?>>
                <label class="form-check-label">Bluetooth</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="features[]" value="camera" <?php echo e(in_array('camera', $features) ? 'checked' : ''); ?>>
                <label class="form-check-label">Camera</label>
            </div>
        </div>

        <!-- Image Upload -->
        <div class="mb-3">
            <label class="form-label">Product Image</label>
            <input type="file" name="image" class="form-control">
            <?php if($product->image): ?>
                <img src="<?php echo e(asset('uploads/'.$product->image)); ?>" alt="Image" class="img-thumbnail mt-2" width="100">
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</div>

<!-- Dependent Dropdown AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$('#category').change(function(){
    let id = $(this).val();
    $.get('/get-subcategories/' + id, function(data){
        $('#subcategory').empty().append('<option value="">Select Subcategory</option>');
        $.each(data, function(key,val){
            $('#subcategory').append('<option value="'+val.id+'">'+val.name+'</option>');
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel-crud\resources\views/products/edit.blade.php ENDPATH**/ ?>