@extends('app')
@section('content')
<div class="container mt-5">
    <h2>Product List</h2>
    <a href="{{ route('products.create') }}" class="btn btn-primary mb-3">Add New Product</a>
    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th><th>Name</th><th>Category</th><th>Subcategory</th><th>Type</th><th>Features</th><th>Image</th><th>Action</th>
            </tr>
        </thead> 
        <tbody>
            @foreach($products as $index => $product)
            <tr>
                <td>{{ $index+1 }}</td>
                <td>{{ $product->name }}</td>
                <td>{{ $product->category->name }}</td>
                <td>{{ $product->subcategory->name }}</td>
                <td>{{ ucfirst($product->type) }}</td>
                <td>
                    @php
                        $features = is_array($product->features) ? $product->features : json_decode($product->features, true) ?? [];
                    @endphp
                    {{ !empty($features) ? implode(', ', $features) : 'N/A' }}
                </td>
                <td>@if($product->image)<img src="{{ asset('uploads/'.$product->image) }}" width="60" class="img-thumbnail">@endif</td>
                <td>
                    <a href="{{ route('products.edit',$product->id) }}" class="btn btn-sm btn-warning">Edit</a>
                    <form action="{{ route('products.destroy',$product->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                        @csrf @method('DELETE')
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
            @if($products->isEmpty())<tr><td colspan="8" class="text-center">No products found.</td></tr>@endif
        </tbody>
    </table>
</div>
@endsection
