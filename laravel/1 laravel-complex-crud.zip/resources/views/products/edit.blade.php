@extends('app')

@section('content')
<div class="container mt-5">
    <h2>Edit Product</h2>
    <a href="{{ route('products.index') }}" class="btn btn-secondary mb-3">Back</a>

    <!-- Validation Errors -->
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <!-- Product Name -->
        <div class="mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $product->name) }}">
        </div>

        <!-- Category -->
        <div class="mb-3">
            <label class="form-label">Category</label>
            <select name="category_id" id="category" class="form-select">
                <option value="">Select Category</option>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ $product->category_id == $cat->id ? 'selected' : '' }}>
                        {{ $cat->name }}
                    </option>
                @endforeach
            </select>
        </div>

        <!-- Subcategory -->
        <div class="mb-3">
            <label class="form-label">Subcategory</label>
            <select name="subcategory_id" id="subcategory" class="form-select">
                <option value="{{ $product->subcategory_id }}">{{ $product->subcategory->name }}</option>
            </select>
        </div>

        <!-- Type (Radio) -->
        <div class="mb-3">
            <label class="form-label d-block">Type</label>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" value="new" {{ $product->type == 'new' ? 'checked' : '' }}>
                <label class="form-check-label">New</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="type" value="used" {{ $product->type == 'used' ? 'checked' : '' }}>
                <label class="form-check-label">Used</label>
            </div>
        </div>

        <!-- Features (Checkbox) -->
        <div class="mb-3">
            <label class="form-label d-block">Features</label>
            @php $features = $product->features ?? []; @endphp
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="features[]" value="wifi" {{ in_array('wifi', $features) ? 'checked' : '' }}>
                <label class="form-check-label">Wifi</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="features[]" value="bluetooth" {{ in_array('bluetooth', $features) ? 'checked' : '' }}>
                <label class="form-check-label">Bluetooth</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="features[]" value="camera" {{ in_array('camera', $features) ? 'checked' : '' }}>
                <label class="form-check-label">Camera</label>
            </div>
        </div>

        <!-- Image Upload -->
        <div class="mb-3">
            <label class="form-label">Product Image</label>
            <input type="file" name="image" class="form-control">
            @if($product->image)
                <img src="{{ asset('uploads/'.$product->image) }}" alt="Image" class="img-thumbnail mt-2" width="100">
            @endif
        </div>

        <button type="submit" class="btn btn-primary">Update Product</button>
    </form>
</div>

<!-- Dependent Dropdown AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$('#category').change(function(){
    let id = $(this).val();
    $.get('/get-subcategories/' + id, function(data){
        $('#subcategory').empty().append('<option value="">Select Subcategory</option>');
        $.each(data, function(key,val){
            $('#subcategory').append('<option value="'+val.id+'">'+val.name+'</option>');
        });
    });
});
</script>
@endsection
