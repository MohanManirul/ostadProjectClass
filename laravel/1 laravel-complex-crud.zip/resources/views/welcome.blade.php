<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apartment Booking</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body{
            min-height: 100vh;
            background:linear-gradient(rgba(245,247,250,0.85),rgba(245,247,250,0.85)),
            url('https://images.unsplash.com/photo-1502672260266-1c1ef2d93688');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .price{
            color: #0d6efd;
            font-weight: 600;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>

<div class="container py-5">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">Apartment Booking</a>
            <div class="d-flex ms-auto">
                <a href="#" class="btn btn-outline-primary me-2" id="loginBtn">Login</a>
                <a href="#" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </nav>

    <!-- Page Title -->
    <div class="text-center mb-5">
        <h2 class="fw-bold">Available Apartments</h2>
        <p class="text-muted">Choose your apartment & book easily</p>
    </div>

    <!-- Apartment Cards -->
    <div class="row g-4" id="apartmentId">
        

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

<script>

    document.getElementById('loginBtn').addEventListener('click',()=>{
        window.location = '/tenant/login'
    })

    data()
    async function  data() {
        let response = await axios.get('/api/v1/apartment-data');
            let data = response.data.data ;
        data.forEach((item)=>{
            let buttonText = 'Book Now' ;
            let isDisable = '' ;
            let statusBadge = '';
            if(item.status === 0 ){
                statusBadge = `<span class="badge bg-success">Available</span>`
            }else if(item.status === 1 ){
                statusBadge = `<span class="badge bg-danger">Booked</span>`
                isDisable = 'disabled';
                buttonText = 'Already Booked'

            }

            document.getElementById('apartmentId').innerHTML += (`
                <div class="col-md-6 col-lg-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/400x250" class="card-img-top" alt="Apartment">
                        <div class="card-body">
                            <h5 class="card-title fw-bold">${item.name}</h5>
                            <p class="text-muted">
                                <i class="bi bi-geo-alt"></i> Gulshan, Dhaka
                            </p>

                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="price">৳ ${item.rent} / Month</span>
                                <span>${statusBadge}</span>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold">Booking Date</label>
                                <div class="row g-2">
                                    <div class="col">
                                        <input type="date" class="form-control form-control-sm start-date" ${isDisable} >
                                    </div>
                                    <div class="col">
                                        <input type="date" class="form-control form-control-sm end-date" ${isDisable}>
                                    </div>
                                </div>
                            </div>

                            <button onclick="handleBooking(this, ${item.id})" class="btn btn-primary w-100 rounded-pill" ${isDisable}>
                                <i class="bi bi-calendar-check"></i> ${buttonText} 
                            </button>
                        </div>
                    </div>
                </div>
            `)
        });
        
    }

 async function handleBooking(button , apartmentId) {
          
        const token = localStorage.getItem('tenant_token');
        if (!token) {
            window.location.href = "/tenant/login";
            return;
        }

       const card = button.closest('.card');
       const startDate = card.querySelector('.start-date').value ;
       const endDate = card.querySelector('.end-date').value ;

       if(!startDate || !endDate){
         alert('Please select booking date range.');
            return;
       }
       let obj = {
                    apartment_id: apartmentId,
                    start_date: startDate,
                    end_date: endDate
                }
                console.log(obj);
                
       try{
             const res = await axios.post(
                '/api/v1/bookings',obj
                ,
                {
                    headers: {
                        Authorization: 'Bearer ' + token
                    }
                }
            );
            console.log(res);
            
            alert('Apartment booked successfully!') ;
            button.disabled = true;
            button.innerHTML = 'Booked';
       }catch(error){
        console.log(error.message);
        
       }

    }
</script>


</body>
</html>
