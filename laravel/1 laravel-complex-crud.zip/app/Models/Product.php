<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = ['name','category_id','subcategory_id','type','features','image'];
    protected $casts = ['features'=>'array']; // JSON কে automatically array হিসেবে cast করবে
    // ✅ Explanation:

    // $casts['features'] = 'array' দিলে, যখন আপনি $product->features access করবেন, এটি PHP array হিসেবে পাবেন।

    // যখন save করবেন, Laravel automatically array কে JSON string হিসেবে DB তে store করবে।

    //     Laravel migration-এ আপনি array data type সরাসরি ব্যবহার করতে পারবেন না।

    // Laravel-supported column types হলো: string, text, integer, boolean, json, float, date, datetime ইত্যাদি।

    // যদি আপনি array save করতে চান, সাধারণত json type ব্যবহার করতে হয়। তারপর Laravel model-এ $casts ব্যবহার করে এটাকে array হিসেবে handle করা যায়।

    public function category()
    { 
        return $this->belongsTo(Category::class); 
    }
    
    public function subcategory()
    { 
        return $this->belongsTo(SubCategory::class); 
    }
}
