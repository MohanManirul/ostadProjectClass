<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\Country;
use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index()
    {
        $posts = Post::with(['country','city'])->get();
        return view('posts.index',compact('posts'));
    }

    public function create()
    {
        $countries = Country::all();
        return view('posts.create',compact('countries'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'=>'required',
            'country_id'=>'required',
            'city_id'=>'required',
            'status'=>'required',
            'skills'=>'required|array',
            'image'=>'image|mimes:jpg,png,jpeg'
        ]);

        $data['skills'] = implode(',', $request->skills);

        if($request->hasFile('image')){
            $data['image'] = $request->file('image')->store('posts','public');
        }

        Post::create($data);
        return redirect()->route('posts.index');
    }

    public function edit($id)
    {
        $post = Post::findOrFail($id);
        $countries = Country::all();
        $cities = City::where('country_id',$post->country_id)->get();
        return view('posts.edit',compact('post','countries','cities'));
    }

    public function update(Request $request,$id)
    {
        $post = Post::findOrFail($id);

        $data = $request->validate([
            'title'=>'required',
            'country_id'=>'required',
            'city_id'=>'required',
            'status'=>'required',
            'skills'=>'required|array',
            'image'=>'image|mimes:jpg,png,jpeg'
        ]);

        $data['skills'] = implode(',', $request->skills);

        if($request->hasFile('image')){
            if($post->image){
                \Storage::disk('public')->delete($post->image);
            }
            $data['image'] = $request->file('image')->store('posts','public');
        }

        $post->update($data);
        return redirect()->route('posts.index');
    }

    public function destroy($id)
    {
        $post = Post::findOrFail($id);
        if($post->image){
            \Storage::disk('public')->delete($post->image);
        }
        $post->delete();
        return back();
    }
}
