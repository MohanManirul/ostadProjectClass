<?php

namespace App\Http\Controllers;
use App\Models\Product;
use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class ProductController extends Controller
{
     public function index(){
        $products = Product::with('category','subcategory')->get();
        return view('products.index', compact('products'));
    }
 
    public function create(){
        $categories = Category::all();
        return view('products.create', compact('categories'));
    }

    public function getSubCategory($id){
        return SubCategory::where('category_id',$id)->get();
    }

    public function store(Request $request){
        $request->validate([
            'name'=>'required',
            'category_id'=>'required',
            'subcategory_id'=>'required',
            'type'=>'required',
            'features'=>'required|array',
            'image'=>'required|image|max:2048'
        ]);

        $imageName = time().'.'.$request->image->extension();
        $request->image->move(public_path('uploads'), $imageName);

        Product::create([
            'name'=>$request->name,
            'category_id'=>$request->category_id,
            'subcategory_id'=>$request->subcategory_id,
            'type'=>$request->type,
            'features'=>$request->features,
            'image'=>$imageName
        ]);

        return redirect()->route('products.index')->with('success','Product Created');
    }

    public function edit(Product $product){
        $categories = Category::all();
        return view('products.edit', compact('product','categories'));
    }

    public function update(Request $request, Product $product){
        $request->validate([
            'name'=>'required',
            'category_id'=>'required',
            'subcategory_id'=>'required',
            'type'=>'required',
            'features'=>'required|array',
            'image'=>'nullable|image|max:2048'
        ]);

        if($request->hasFile('image')){
            $imageName = time().'.'.$request->image->extension();
            $request->image->move(public_path('uploads'), $imageName);
            $product->image = $imageName;
        }

        $product->update([
            'name'=>$request->name,
            'category_id'=>$request->category_id,
            'subcategory_id'=>$request->subcategory_id,
            'type'=>$request->type,
            'features'=>$request->features
        ]);

        return redirect()->route('products.index')->with('success','Product Updated');
    }

    public function destroy(Product $product){
        $product->delete();
        return redirect()->route('products.index')->with('success','Product Deleted');
    }
}