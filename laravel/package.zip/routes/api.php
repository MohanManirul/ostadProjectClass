<?php

use App\Http\Controllers\API\V1\AdminDashboardController;
use App\Http\Controllers\API\V1\ApartmentController;
use App\Http\Controllers\API\V1\BookingController;
use App\Http\Controllers\API\V1\DashboardController;
use App\Http\Controllers\API\V1\TenantController;
use App\Models\Apartment;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
  
    
});



 